import React from "react";

const FlashPage=()=>{
    return(
        <>
        <div className="card">
            <div className="row m-2">Flash Message</div>
        </div>
        </>
    )
}
export default FlashPage;