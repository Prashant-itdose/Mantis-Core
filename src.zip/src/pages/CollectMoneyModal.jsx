import React from "react";

const CollectMoneyModal=(visible)=>{
console.log(visible)
    return(
        <>
        <div className="card">
            <div className="row m-2">
                Admin: <br></br>
                Sale: <br></br>
                Total: 8000
            </div>
        </div>
        </>
    )
}
export default CollectMoneyModal;