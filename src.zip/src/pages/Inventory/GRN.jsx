import React from "react";
import Heading from "../../components/UI/Heading";

const GRN = () => {
  return (
    <>
      <div className="card">
        <Heading isBreadcrumb={true} />
        <div className="row p-2">GRN</div>
      </div>
    </>
  );
};
export default GRN;
