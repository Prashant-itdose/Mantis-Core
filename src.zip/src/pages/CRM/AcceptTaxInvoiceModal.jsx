import React from "react";

const AcceptTaxInvoiceModal=()=>{

    return(
        <>
        <div className="row m-2">Accept</div>
        </>
    )
}

export default AcceptTaxInvoiceModal;