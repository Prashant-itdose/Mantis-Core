import React from "react";

const CalendarAttendanceModal=()=>{

    return(
        <>
        <div className="card">
            <div className="row p-2">
                Hello Calendar
            </div>
        </div>
        </>
    )
}

export default CalendarAttendanceModal