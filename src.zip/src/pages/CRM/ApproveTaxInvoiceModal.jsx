import React from "react";

const ApproveTaxInvoiceModal = () => {
  return (
    <>
      <div className="row m-2">Approve</div>
    </>
  );
};

export default ApproveTaxInvoiceModal;
