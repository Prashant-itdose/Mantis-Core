import React from 'react'

const Blank = () => {
  return (
    <div>Compokanent</div>
  )
}

export default Blank