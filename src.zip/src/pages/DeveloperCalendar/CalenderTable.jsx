import React from "react";
import './DeveloperCalender.css'

const CalendarTable=()=>{
    return (
        <>
            <div className="w-100 border px-4">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ex qui tempore similique quis eos aliquid cupiditate facilis soluta, nesciunt porro illum aperiam asperiores sint quidem nemo excepturi nisi maiores totam?
            </div>
        </>
    )
}

export default CalendarTable;