/* eslint-env jest */

test('renders learn react link', () => {
  expect(true).toBeTruthy();
});

export {};
